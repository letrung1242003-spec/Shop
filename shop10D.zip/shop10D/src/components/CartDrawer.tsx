import { useStore } from "@/context/StoreContext";
import { useState } from "react";
import { toast } from "sonner";

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
}

const CartDrawer = ({ open, onClose }: CartDrawerProps) => {
  const { cart, updateQuantity, removeFromCart, cartTotal, placeOrder } = useStore();
  const [name, setName] = useState("");

  const handleOrder = () => {
    if (!name.trim()) {
      toast.error("Nhập tên để đặt hàng nhé! 🥺");
      return;
    }
    if (cart.length === 0) {
      toast.error("Giỏ hàng trống rồi! 🛒");
      return;
    }
    placeOrder(name.trim());
    setName("");
    toast.success("Đặt hàng thành công! 🎉");
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="absolute inset-0 bg-foreground/20 backdrop-blur-sm" onClick={onClose} />
      <div className="ml-auto w-full max-w-sm bg-card h-full relative z-10 p-5 flex flex-col bounce-in overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-extrabold text-foreground">🛒 Giỏ hàng</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground text-2xl">✕</button>
        </div>

        {cart.length === 0 ? (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-muted-foreground text-center">Chưa có món nào 🥺<br />Thêm món ngon nhé!</p>
          </div>
        ) : (
          <>
            <div className="flex-1 space-y-3">
              {cart.map(item => (
                <div key={item.id} className="flex items-center gap-3 bg-muted rounded-xl p-3">
                  <span className="text-2xl">{item.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-sm text-foreground truncate">{item.name}</p>
                    <p className="text-xs text-primary font-bold">{(item.price * item.quantity).toLocaleString("vi-VN")}đ</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="w-7 h-7 rounded-full bg-primary/10 text-primary font-bold text-sm hover:bg-primary/20">−</button>
                    <span className="w-6 text-center font-bold text-sm">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="w-7 h-7 rounded-full bg-primary/10 text-primary font-bold text-sm hover:bg-primary/20">+</button>
                  </div>
                  <button onClick={() => removeFromCart(item.id)} className="text-destructive hover:text-destructive/80 text-sm">🗑</button>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-4 border-t border-border space-y-3">
              <div className="flex justify-between font-extrabold text-lg">
                <span>Tổng</span>
                <span className="text-primary">{cartTotal.toLocaleString("vi-VN")}đ</span>
              </div>
              <input
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Tên của bạn ✨"
                className="w-full px-4 py-3 rounded-xl bg-muted text-foreground placeholder:text-muted-foreground font-semibold text-sm outline-none focus:ring-2 focus:ring-ring"
              />
              <button
                onClick={handleOrder}
                className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-extrabold text-base hover:opacity-90 transition-opacity active:scale-[0.98]"
              >
                Đặt hàng 🎉
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CartDrawer;
