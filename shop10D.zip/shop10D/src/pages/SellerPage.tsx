import { useState } from "react";
import { Link } from "react-router-dom";
import { useStore } from "@/context/StoreContext";
import { Order } from "@/data/menu";
import { toast } from "sonner";

const SELLER_PASSWORD = "1234";

const statusConfig: Record<Order["status"], { label: string; emoji: string; bg: string }> = {
  pending: { label: "Chờ làm", emoji: "⏳", bg: "bg-kawaii-yellow" },
  preparing: { label: "Đang làm", emoji: "👨‍🍳", bg: "bg-kawaii-mint" },
  done: { label: "Xong!", emoji: "✅", bg: "bg-kawaii-lavender" },
};

const nextStatus: Record<Order["status"], Order["status"] | null> = {
  pending: "preparing",
  preparing: "done",
  done: null,
};

const SellerPage = () => {
  const [authenticated, setAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="bg-card rounded-2xl p-6 kawaii-shadow w-full max-w-sm text-center space-y-4">
          <p className="text-4xl">🔒</p>
          <h2 className="text-lg font-extrabold text-foreground">Trang dành cho người bán</h2>
          <p className="text-sm text-muted-foreground">Nhập mật khẩu để tiếp tục</p>
          <input
            type="password"
            value={password}
            onChange={e => { setPassword(e.target.value); setError(false); }}
            onKeyDown={e => {
              if (e.key === "Enter") {
                if (password === SELLER_PASSWORD) setAuthenticated(true);
                else setError(true);
              }
            }}
            placeholder="Mật khẩu..."
            className="w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          {error && <p className="text-xs text-destructive font-semibold">Sai mật khẩu, thử lại nhé! 😅</p>}
          <button
            onClick={() => {
              if (password === SELLER_PASSWORD) setAuthenticated(true);
              else setError(true);
            }}
            className="w-full bg-primary text-primary-foreground rounded-full py-3 font-bold text-sm hover:opacity-90 transition-opacity"
          >
            Vào trang quản lý
          </button>
          <Link to="/" className="block text-xs text-muted-foreground hover:text-primary transition-colors">
            ← Quay lại trang mua hàng
          </Link>
        </div>
      </div>
    );
  }

  return <SellerDashboard />;
};

const SellerDashboard = () => {
  const { orders, updateOrderStatus } = useStore();

  const handleNext = (order: Order) => {
    const next = nextStatus[order.status];
    if (next) {
      updateOrderStatus(order.id, next);
      toast.success(`Đơn #${order.id.slice(-4)} → ${statusConfig[next].label} ${statusConfig[next].emoji}`);
    }
  };

  const activeOrders = orders.filter(o => o.status !== "done");
  const doneOrders = orders.filter(o => o.status === "done");

  return (
    <div className="min-h-screen bg-background pb-8">
      <header className="sticky top-0 z-40 bg-card/80 backdrop-blur-md border-b border-border px-4 py-3">
        <div className="max-w-lg mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-xl font-extrabold text-foreground">👨‍🍳 Quản lý đơn</h1>
            <p className="text-xs text-muted-foreground">Xem và xử lý đơn hàng</p>
          </div>
          <Link to="/" className="bg-primary text-primary-foreground rounded-full px-4 py-2 text-sm font-bold hover:opacity-90 transition-opacity">
            🛍️ Trang khách hàng
          </Link>
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 mt-4 space-y-4">
        {activeOrders.length === 0 && doneOrders.length === 0 && (
          <div className="text-center py-16">
            <p className="text-4xl mb-2">📋</p>
            <p className="text-muted-foreground font-semibold">Chưa có đơn hàng nào</p>
          </div>
        )}

        {activeOrders.length > 0 && (
          <div>
            <h2 className="font-extrabold text-foreground mb-3">📌 Đơn đang xử lý ({activeOrders.length})</h2>
            <div className="space-y-3">
              {activeOrders.map(order => (
                <OrderCard key={order.id} order={order} onNext={() => handleNext(order)} />
              ))}
            </div>
          </div>
        )}

        {doneOrders.length > 0 && (
          <div>
            <h2 className="font-extrabold text-foreground mb-3 mt-6">✅ Đã hoàn thành ({doneOrders.length})</h2>
            <div className="space-y-3 opacity-60">
              {doneOrders.map(order => (
                <OrderCard key={order.id} order={order} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const OrderCard = ({ order, onNext }: { order: Order; onNext?: () => void }) => {
  const status = statusConfig[order.status];
  const next = nextStatus[order.status];

  return (
    <div className="bg-card rounded-2xl p-4 kawaii-shadow bounce-in">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className={`${status.bg} px-3 py-1 rounded-full text-xs font-bold`}>
            {status.emoji} {status.label}
          </span>
          <span className="text-xs text-muted-foreground">#{order.id.slice(-4)}</span>
        </div>
        <span className="text-xs text-muted-foreground">{order.createdAt}</span>
      </div>

      <p className="font-bold text-foreground mb-2">👤 {order.customerName}</p>

      <div className="space-y-1 mb-3">
        {order.items.map(item => (
          <div key={item.id} className="flex justify-between text-sm">
            <span className="text-foreground">
              {item.emoji} {item.name} × {item.quantity}
            </span>
            <span className="text-muted-foreground font-semibold">
              {(item.price * item.quantity).toLocaleString("vi-VN")}đ
            </span>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-border">
        <span className="font-extrabold text-primary">{order.total.toLocaleString("vi-VN")}đ</span>
        {next && onNext && (
          <button
            onClick={onNext}
            className="bg-primary text-primary-foreground rounded-full px-4 py-2 text-sm font-bold hover:opacity-90 transition-opacity active:scale-95"
          >
            {next === "preparing" ? "👨‍🍳 Bắt đầu làm" : "✅ Hoàn thành"}
          </button>
        )}
      </div>
    </div>
  );
};

export default SellerPage;
