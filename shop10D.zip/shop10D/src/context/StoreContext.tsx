import React, { createContext, useContext, useState, useCallback } from "react";
import { CartItem, MenuItem, Order } from "@/data/menu";

interface StoreContextType {
  cart: CartItem[];
  orders: Order[];
  addToCart: (item: MenuItem) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  placeOrder: (customerName: string) => void;
  updateOrderStatus: (orderId: string, status: Order["status"]) => void;
  cartTotal: number;
  cartCount: number;
}

const StoreContext = createContext<StoreContextType | null>(null);

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
};

const loadOrders = (): Order[] => {
  try {
    const saved = localStorage.getItem("kawaii-orders");
    return saved ? JSON.parse(saved) : [];
  } catch { return []; }
};

const saveOrders = (orders: Order[]) => {
  localStorage.setItem("kawaii-orders", JSON.stringify(orders));
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>(loadOrders);

  const addToCart = useCallback((item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.id === item.id);
      if (existing) {
        return prev.map(c => c.id === item.id ? { ...c, quantity: c.quantity + 1 } : c);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  }, []);

  const removeFromCart = useCallback((id: string) => {
    setCart(prev => prev.filter(c => c.id !== id));
  }, []);

  const updateQuantity = useCallback((id: string, quantity: number) => {
    if (quantity <= 0) {
      setCart(prev => prev.filter(c => c.id !== id));
    } else {
      setCart(prev => prev.map(c => c.id === id ? { ...c, quantity } : c));
    }
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const placeOrder = useCallback((customerName: string) => {
    const newOrder: Order = {
      id: Date.now().toString(),
      items: [...cart],
      customerName,
      total: cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
      status: "pending",
      createdAt: new Date().toLocaleString("vi-VN"),
    };
    const updated = [newOrder, ...orders];
    setOrders(updated);
    saveOrders(updated);
    setCart([]);
  }, [cart, orders]);

  const updateOrderStatus = useCallback((orderId: string, status: Order["status"]) => {
    setOrders(prev => {
      const updated = prev.map(o => o.id === orderId ? { ...o, status } : o);
      saveOrders(updated);
      return updated;
    });
  }, []);

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <StoreContext.Provider value={{
      cart, orders, addToCart, removeFromCart, updateQuantity,
      clearCart, placeOrder, updateOrderStatus, cartTotal, cartCount,
    }}>
      {children}
    </StoreContext.Provider>
  );
};
